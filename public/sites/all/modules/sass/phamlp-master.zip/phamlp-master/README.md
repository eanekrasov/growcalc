### How to use from the command line

for put sass files in watch mode, and output css is written to file .css:

	sassc watch ./tests/scss

If you are in windows, have to set PHP_COMMAND environment var for php.exe path. Example:

	set PHP_COMMAND=c:\xampp\php\php.exe
