stylesheet 'grid.sass', :media => "screen, projection"
stylesheet 'text.sass', :media => "screen, projection"

description "The 960 Grid System."

help %Q{
Please see the 960 website for documentation:

    http://960.gs/
}

welcome_message %Q{
Please see the 960 website for documentation:

    http://960.gs/
}

